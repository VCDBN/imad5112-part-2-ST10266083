package com.varsitycollege.st10266083
// All the imports.
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.abs
import kotlin.math.sqrt

// Reference:https://stackoverflow.com/questions/12974991/dynamically-added-button-eventlistener
// Reference:https://www.geeksforgeeks.org/kotlin-when-expression/
// Reference:https://xiith.com/kotlin/kotlin-program-to-find-the-square-root-of-a-number/#:~:text=Example%3A%20How%20to%20find%20the%20square%20root%20of,println%28%22Square%20Root%20of%20%3A%24num%20is%20%3A%24result%22%29%20%7D%20Output%3A
// Reference:https://runebook.dev/en/docs/kotlin/api/latest/jvm/stdlib/kotlin.math/pow#:~:text=kotlin-stdlib%20%2F%20kotlin.math%20%2F%20pow%20Platform%20and%20version,Float%20Raises%20this%20value%20to%20the%20power%20x.
// Reference:https://youtu.be/v24Bhk7wQI8
// Reference:https://youtu.be/Zi1XgFTUH9k

    class MainActivity : AppCompatActivity() {

        // Creating private variables
        private lateinit var number1EditText: EditText
        private lateinit var number2EditText: EditText
        private lateinit var resultTextView: TextView
        private lateinit var plusButton: Button
        private lateinit var minusButton: Button
        private lateinit var timesButton: Button
        private lateinit var divideButton: Button
        private lateinit var PowerButton: Button
        private lateinit var SquareRootButton: Button

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            // Creating User interface with IDS.
            number1EditText = findViewById(R.id.number1EditText)
            number2EditText = findViewById(R.id.number2EditText)
            resultTextView = findViewById(R.id.resultTextView)
            plusButton = findViewById(R.id.plusButton)
            minusButton = findViewById(R.id.minusButton)
            timesButton = findViewById(R.id.timesButton)
            divideButton = findViewById(R.id.divideButton)
            PowerButton = findViewById(R.id.PowerButton)
            SquareRootButton = findViewById(R.id.SquareRootButton)

            // Setting click listeners for the buttons

            // Addition Button
            plusButton.setOnClickListener {

                val num1 = number1EditText.text.toString().toInt()
                val num2 = number2EditText.text.toString().toInt()
                addition(num1, num2)
            }
            // Subtraction Button
            minusButton.setOnClickListener {

                val num1 = number1EditText.text.toString().toInt()
                val num2 = number2EditText.text.toString().toInt()
                subtraction(num1, num2)
            }
            // Multiplication Button
            timesButton.setOnClickListener {

                val num1 = number1EditText.text.toString().toInt()
                val num2 = number2EditText.text.toString().toInt()
                multiplication(num1, num2)
            }
            // Division Button
            divideButton.setOnClickListener {

                val num1 = number1EditText.text.toString().toInt()
                val num2 = number2EditText.text.toString().toInt()
                division(num1, num2)
            }
            // Square Root Button
            SquareRootButton.setOnClickListener {
                val num1 = number1EditText.text.toString().toInt()
                squareRoot(num1)

            }
            // Power Button
            PowerButton.setOnClickListener {
                val num1 = number1EditText.text.toString().toInt()
                val num2 = number2EditText.text.toString().toInt()
                val result = power(num1, num2)
                resultTextView.text = "$num1^$num2 = $result"

            }
        }

        // Creating a function to perform all the arithmetic tasks
        private fun addition(num1: Int, num2: Int) {
            val result = num1 + num2

            // Display the result for all the calculations
            resultTextView.text = "$num1 + $num2 = $result"
        }

        private fun subtraction(num1: Int, num2: Int) {
            val result = num1 - num2

            // Display the result for all the calculations
            resultTextView.text = "$num1 - $num2 = $result"
        }

        private fun multiplication(num1: Int, num2: Int) {
            val result = num1 * num2

            // Display the result for all the calculations
            resultTextView.text = "$num1 * $num2 = $result"
        }

        // Function to perform division
        private fun division(num1: Int, num2: Int) {
            val result = if (num2 != 0) num1.toDouble() / num2.toDouble() else Double.NaN
            resultTextView.text =
                if (!result.isNaN()) "Result: $num1 / $num2 = $result" else "Error: Division by 0 is not allowed"
        }

        // Function to calculate square root
        private fun squareRoot(num1: Int) {
            val result: String = if (num1 >= 0) {
                val squareRoot = sqrt(num1.toDouble())
                "sqrt($num1) = $squareRoot"
            } else {
                val absNum = abs(num1)
                val imaginaryPart = sqrt(absNum.toDouble())
                "sqrt(-$absNum) = ${imaginaryPart}i"
            }

            result.also { resultTextView.text = it }
        }
        // Function to calculate power
        private fun power(base: Int, exponent: Int): Double {
            var result = 1.0
            for (i in 1..exponent) {
                result *= base
            }
            return result

        }
    }